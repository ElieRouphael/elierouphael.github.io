# A Tour of Machine Learning

Eleven standalone notebooks, each covering one machine-learning idea end to end:
regression, the calculus behind training, SVMs, random forests, K-means, a neural
network from scratch, transfer learning, LSTMs, anomaly detection, transformers, and
federated learning. Unlike a sequential course, chapters don't depend on each other's
results — read any one on its own.

This reworks material from Elie Rouphael's own **MADIS Machine Learning Workshop**
(`../TP_MADIS_Machine_Learning_with_Pyhon.ipynb`) into runnable, self-contained
chapters, each on real data. Chapter 04 (Random Forest) loosely follows the structure
of Prashant Banerjee's [Random Forest Classifier
Tutorial](https://www.kaggle.com/code/prashant111/random-forest-classifier-tutorial);
chapter 09 (Anomaly Detection) follows the general recipe of the Keras [Timeseries
anomaly detection using an Autoencoder](https://keras.io/examples/timeseries/timeseries_anomaly_detection/)
example — both cited in the original workshop's closing notes.

## Roadmap

| # | Chapter | Data |
|---|---------|------|
| 01 | [Linear Regression](01_linear_regression.ipynb) | `data/data.csv` (CO2 vs. weight/volume) |
| 02 | [Finding Minima and Maxima](02_minima_and_maxima.ipynb) | toy functions (sympy) |
| 03 | [Support Vector Machines](03_support_vector_machines.ipynb) | `data/iris.csv` |
| 04 | [Random Forest](04_random_forest.ipynb) | `data/heart.csv` |
| 05 | [K-Means and K-Means++](05_kmeans_and_kmeans_plusplus.ipynb) | `data/Mall_Customers.csv` |
| 06 | [A Neural Network from Scratch](06_neural_network_from_scratch.ipynb) | synthetic (`make_moons`) |
| 07 | [Transfer Learning](07_transfer_learning.ipynb) | `sklearn` digits (built in) |
| 08 | [LSTM for Sequences](08_lstm_for_sequences.ipynb) | synthetic sine series |
| 09 | [Anomaly Detection with an Autoencoder](09_anomaly_detection_autoencoder.ipynb) | `data/art_daily_small_noise.csv`, `data/art_daily_jumpsup.csv` |
| 10 | [Transformers and Self-Attention](10_transformers_self_attention.ipynb) | hand-built toy sequence |
| 11 | [Federated Learning](11_federated_learning.ipynb) | `data/diabetes.csv` |

## Getting started

```bash
python -m venv course_venv
course_venv\Scripts\activate          # macOS/Linux: source course_venv/bin/activate
pip install -r requirements.txt
jupyter lab
```

Each notebook is self-contained (open any one directly); run `build_notebooks.py` to
execute all eleven and write fully-executed copies to `executed/`, which is what the
course website renders. On a laptop the full run takes a few minutes.

```bash
python build_notebooks.py            # all chapters
python build_notebooks.py 07 09      # only the named chapters
```

## Structure

```
course/
├── 01_linear_regression.ipynb ... 11_federated_learning.ipynb   (no outputs)
├── mlutils.py            shared matplotlib style
├── data/                 CSVs used by the chapters (copied from ../DataSets, ../Datasets_new)
├── build_notebooks.py    executes every chapter, writes executed/
├── executed/             chapters with outputs (generated, not committed content-wise but produced by the build)
└── requirements.txt
```

## License

MIT, following the parent workshop repository.
