"""Execute every chapter notebook independently and save executed copies to executed/.

Unlike a sequential course, each chapter here is a self-contained idea (linear
regression, SVMs, an autoencoder, ...), so chapters do not depend on each other's
results. The notebooks are kept without outputs in source control; this script runs
them with nbclient and writes fully-executed copies to executed/, which is what the
course website renders.

Usage (from this folder, with course_venv activated or its python.exe called directly):
    python build_notebooks.py            # all chapters
    python build_notebooks.py 07 09      # only the named chapters
"""

import sys
import time
from pathlib import Path

import nbformat
from nbclient import NotebookClient

HERE = Path(__file__).resolve().parent
OUT = HERE / "executed"


def main() -> None:
    wanted = set(sys.argv[1:])
    notebooks = sorted(p for p in HERE.glob("[0-9][0-9]_*.ipynb") if not wanted or p.name[:2] in wanted)
    OUT.mkdir(exist_ok=True)
    total = 0.0
    for path in notebooks:
        start = time.time()
        nb = nbformat.read(path, as_version=4)
        NotebookClient(nb, timeout=1800, resources={"metadata": {"path": str(HERE)}}).execute()
        nbformat.write(nb, OUT / path.name)
        dt = time.time() - start
        total += dt
        print(f"{path.name}: {dt:.0f}s")
    print(f"total: {total:.0f}s")


if __name__ == "__main__":
    main()
