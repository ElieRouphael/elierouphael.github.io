"""Small shared plotting helpers for the "A Tour of Machine Learning" course notebooks.

Each chapter in this course is a self-contained notebook (unlike a sequential course,
there's no shared scoreboard). This module only holds a consistent visual style so the
eleven chapters, covering very different topics, still look like one course.
"""
import matplotlib.pyplot as plt

INK = "#1d2530"
BLUE = "#2a78d6"
ORANGE = "#eb6834"
GREY = "#8a949e"
GREEN = "#3f9142"
BG = "#fbfbf8"
PALETTE = [BLUE, ORANGE, GREEN, GREY, "#a24fb0", "#c9a227"]


def set_style() -> None:
    plt.rcParams.update({
        "figure.facecolor": BG,
        "axes.facecolor": BG,
        "savefig.facecolor": BG,
        "axes.edgecolor": "#b9bfb6",
        "axes.labelcolor": INK,
        "axes.titlecolor": INK,
        "text.color": INK,
        "xtick.color": INK,
        "ytick.color": INK,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "figure.dpi": 110,
        "font.size": 11,
        "axes.grid": True,
        "grid.color": "#e4e4dc",
        "grid.linewidth": 0.6,
        "axes.axisbelow": True,
    })
