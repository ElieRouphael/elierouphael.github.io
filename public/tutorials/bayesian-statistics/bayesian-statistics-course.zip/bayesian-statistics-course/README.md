# Bayesian Statistics from Scratch

A ten-chapter course that builds Bayesian statistics from Bayes' theorem to
regression and Markov chain Monte Carlo. Each chapter derives the mathematics, then
checks every result in Python (numpy, scipy and matplotlib only).

## Setup

```bash
pip install -r requirements.txt
jupyter notebook            # then open notebooks/00_overview.ipynb
```

## Chapters

| # | Notebook | Topics |
|---|----------|--------|
| 00 | `00_overview` | Three meanings of probability; the Bayesian recipe; a first posterior |
| 01 | `01_probability_and_bayes` | Conditional probability, total probability, Bayes' theorem, odds and likelihood ratios |
| 02 | `02_distributions` | Expectation and variance, discrete and continuous families, the central limit theorem |
| 03 | `03_likelihood_and_frequentist` | Likelihood, maximum likelihood, Fisher information, confidence intervals and their coverage |
| 04 | `04_prior_to_posterior` | Continuous Bayes, grid approximation, credible intervals, posterior predictive, sequential updating |
| 05 | `05_discrete_conjugate` | Beta-binomial and Poisson-gamma; an A/B test; predictive distributions |
| 06 | `06_continuous_conjugate` | Exponential-gamma, normal mean with known variance, normal-inverse-gamma and the t marginal |
| 07 | `07_priors` | Elicitation, improper priors, Jeffreys priors, prior predictive checks, sensitivity analysis |
| 08 | `08_linear_regression` | Reference and conjugate priors, exact sampling, credible and prediction bands, ridge, posterior predictive checks |
| 09 | `09_mcmc` | Monte Carlo error, the Metropolis algorithm, tuning, effective sample size, R-hat, logistic regression |

## Editing

The notebooks are generated. The source of each chapter is `chapters/NN_name.md`
(markdown with `python` code blocks). After editing a chapter, rebuild and re-execute
its notebook with:

```bash
python build_notebooks.py 05        # or with no argument for all chapters
```

This needs `nbformat`, `nbclient` and `ipykernel` in addition to the requirements.
