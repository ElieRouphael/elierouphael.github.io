"""Build the course notebooks from the chapter sources and execute them.

Each chapters/NN_name.md is markdown with ```python blocks. Markdown is split into
one cell per section heading, each ```python block becomes a code cell, and the
resulting notebook is executed so that it ships with its outputs.

Usage:
    pip install nbformat nbclient ipykernel numpy scipy matplotlib
    python build_notebooks.py            # all chapters
    python build_notebooks.py 05 06      # only chapters whose number is given
"""

import re
import sys
from pathlib import Path

import nbformat
from nbclient import NotebookClient

ROOT = Path(__file__).resolve().parent
SRC, OUT = ROOT / "chapters", ROOT / "notebooks"
FENCE = re.compile(r"^```python\s*\n(.*?)^```\s*$", re.M | re.S)


def split_markdown(text):
    """One markdown cell per heading, so the notebook has a sensible outline."""
    cells, current = [], []
    for line in text.strip("\n").splitlines():
        if re.match(r"#{2,3} ", line) and any(l.strip() for l in current):
            cells.append("\n".join(current).strip("\n"))
            current = []
        current.append(line)
    if any(l.strip() for l in current):
        cells.append("\n".join(current).strip("\n"))
    return cells


def build(md_path):
    text = md_path.read_text(encoding="utf-8")
    nb = nbformat.v4.new_notebook()
    nb.metadata.kernelspec = {"name": "python3", "display_name": "Python 3", "language": "python"}
    pos = 0
    for m in FENCE.finditer(text):
        nb.cells += [nbformat.v4.new_markdown_cell(c) for c in split_markdown(text[pos:m.start()])]
        nb.cells.append(nbformat.v4.new_code_cell(m.group(1).rstrip("\n")))
        pos = m.end()
    nb.cells += [nbformat.v4.new_markdown_cell(c) for c in split_markdown(text[pos:])]

    NotebookClient(nb, timeout=900, kernel_name="python3",
                   resources={"metadata": {"path": str(OUT)}}).execute()
    out = OUT / (md_path.stem + ".ipynb")
    nbformat.write(nb, out)
    n_code = sum(c.cell_type == "code" for c in nb.cells)
    print(f"{out.name}: {len(nb.cells)} cells ({n_code} code), executed")


if __name__ == "__main__":
    OUT.mkdir(exist_ok=True)
    wanted = set(sys.argv[1:])
    for md in sorted(SRC.glob("[0-9][0-9]_*.md")):
        if not wanted or md.name[:2] in wanted:
            build(md)
