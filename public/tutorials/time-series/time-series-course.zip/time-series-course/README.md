# Understanding Time Series: A Practical Course in Python

A hands-on course in time-series analysis and forecasting. It follows **one real dataset**, hourly air quality in Beijing, from raw CSV to deep-learning forecasts, so every method is judged on the same data against the same baselines.

**Author:** Elie Rouphael

## Who this is for

You're comfortable with Python and have used pandas and matplotlib a little. No prior time-series knowledge is assumed. The statistics start from first principles.

## Roadmap

| # | Chapter | Status |
|---|---------|--------|
| 01 | [Working with Time in pandas](01_time_in_pandas.ipynb): timestamps, index health, sentinel values, gaps, resampling, rolling windows, lags, calendar features, seasonal subseries plots, long vs. wide tables | ✅ |
| 02 | [Anatomy of a Time Series](02_anatomy_of_a_time_series.ipynb): trend, seasonality, remainder; additive vs. multiplicative; classical decomposition from scratch; STL; finding periods with the periodogram; component strength | ✅ |
| 03 | [Stationarity](03_stationarity.ipynb): random walks vs. mean reversion, half-lives, ADF + KPSS and their blind spots, test power by simulation, differencing vs. detrending, over-differencing | ✅ |
| 04 | [Baselines and Honest Evaluation](04_baselines_and_evaluation.ipynb): six baselines, MAE/RMSE/MASE and why not MAPE, rolling-origin backtesting, leakage, empirical prediction intervals, the course scoreboard | ✅ |
| 05 | [Exponential Smoothing](05_exponential_smoothing.ipynb): SES from scratch, fitting objectives and per-horizon α, Holt, damped trend, Holt-Winters, ETS with AIC and interval coverage | ✅ |
| 06 | [Autocorrelation and ARMA](06_autocorrelation_and_arma.ipynb): ACF/PACF from scratch, AR/MA/ARMA fingerprints, stationarity and invertibility, AIC/BIC, Ljung–Box, mean-reverting forecasts, seasonal profile + AR(2) | ✅ |
| 07 | [ARIMA, SARIMA and SARIMAX](07_arima_sarima_sarimax.ipynb): ARIMA(0,1,1) = SES, the airline model on CO₂, full residual diagnostics, `auto_arima`, cross-correlation, regression with ARMA errors, weather inputs, oracle vs. honest evaluation, monthly refits | ✅ |
| 08 | [Prophet](08_prophet.ipynb): Fourier seasonality from scratch, changepoints and `changepoint_range`, Spring Festival holiday effects, why Prophet lacks memory, Prophet + AR hybrid, extra regressors, built-in cross-validation, logistic growth, when to use it | ✅ |
| 09 | [Machine Learning for Forecasting](09_machine_learning.ipynb): forecasting as supervised learning, honest features and training cut-offs, direct vs. recursive, ridge vs. gradient boosting, three leakage traps measured | ✅ |
| 10 | [Deep Learning](10_deep_learning.ipynb): honest windows, training-only scaling, time-ordered early stopping, MLP, SimpleRNN and LSTM, seed variability and ensembles, better model vs. better inputs, hourly next-24-hours forecasting | ✅ |
| 11 | [Capstone: The Final Test](11_capstone.ipynb): finalists fixed in advance, the locked 2015 year opened once, 2014 vs. 2015, skill scores, a smog-alert forecast, and the same methods on temperature | ✅ |

Every chapter follows the same pattern: **objectives → intuition → code → pitfalls → exercises (solutions collapsed) → key takeaways**.

## Getting started

```bash
python -m venv .venv
.venv\Scripts\activate          # macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
jupyter lab
```

Run the notebooks from inside this `course/` folder so `import tsutils` and the `data/` paths resolve. Run them **in order**: from chapter 04 on, each chapter adds its scores to `results/` and compares against earlier ones.

## Repository layout

```
course/
├── 01_time_in_pandas.ipynb
├── 02_anatomy_of_a_time_series.ipynb
├── 03_stationarity.ipynb
├── 04_baselines_and_evaluation.ipynb
├── 05_exponential_smoothing.ipynb
├── 06_autocorrelation_and_arma.ipynb
├── 07_arima_sarima_sarimax.ipynb
├── 08_prophet.ipynb
├── 09_machine_learning.ipynb
├── 10_deep_learning.ipynb
├── 11_capstone.ipynb
├── tsutils.py          shared plotting style, data loaders, stationarity tests, backtesting and metrics
├── requirements.txt
├── results/            scoreboard shared across chapters, plus oracle scores kept separately (rebuilt when notebooks run)
└── data/
    ├── README.md       sources and licences for every dataset
    └── beijing_pm25.csv
```

## The forecasting task

From chapter 04 on, every model forecasts **daily mean PM2.5 1–7 days ahead**. Models are compared on a rolling-origin backtest over **2014**, and scores are saved to `results/`. **2015 is locked away** until the capstone, so the final comparison is on data no decision was ever based on.

## Data

See [data/README.md](data/README.md) for sources, citations and licences.
