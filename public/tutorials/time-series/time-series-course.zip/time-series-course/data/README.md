# Data sources

## `beijing_pm25.csv`

Hourly PM2.5 concentrations and weather observations for Beijing, 1 Jan 2010 – 31 Dec 2015 (52,584 rows). This is the `Beijing` file from the *PM2.5 Data of Five Chinese Cities* collection, unmodified apart from the file name.

- **Citation:** Chen, Song (2016). *PM2.5 Data of Five Chinese Cities*. UCI Machine Learning Repository. https://doi.org/10.24432/C52K58
- **Licence:** Creative Commons Attribution 4.0 International (CC BY 4.0), as stated on the dataset's UCI page. Reuse is allowed with attribution.
- **Known quirk:** one hour (2015-11-07 13:00) records `precipitation` and `Iprec` as 999990, a missing-data code. `tsutils.load_beijing()` replaces it with NaN (chapter 01 shows how to spot it).

| Column | Meaning |
|---|---|
| `No` | row number |
| `year`, `month`, `day`, `hour` | timestamp components (local time) |
| `season` | season code |
| `PM_US Post` | PM2.5 (µg/m³) at the US Embassy monitor |
| `PM_Dongsi`, `PM_Dongsihuan`, `PM_Nongzhanguan` | PM2.5 (µg/m³) at three municipal stations (from 2013) |
| `DEWP` | dew point (°C) |
| `HUMI` | relative humidity (%) |
| `PRES` | air pressure (hPa) |
| `TEMP` | temperature (°C) |
| `cbwd` | combined wind direction (`NW`, `NE`, `SE`, `cv` = calm/variable) |
| `Iws` | cumulated wind speed (m/s) |
| `precipitation` | hourly precipitation (mm) |
| `Iprec` | cumulated precipitation (mm) |

## Mauna Loa CO₂ (no file; ships with statsmodels)

Weekly atmospheric CO₂ concentrations (ppm) at Mauna Loa Observatory, Hawaii, 1958–2001, loaded with `statsmodels.api.datasets.co2.load_pandas()`. Used in chapter 02.

- **Citation:** Keeling, C.D. and T.P. Whorf (2004). *Atmospheric CO₂ concentrations derived from flask air samples at sites in the SIO network.* In *Trends: A Compendium of Data on Global Change*. Carbon Dioxide Information Analysis Center, Oak Ridge National Laboratory, U.S. Department of Energy.
- **Licence:** public domain (as stated in the statsmodels dataset documentation).
