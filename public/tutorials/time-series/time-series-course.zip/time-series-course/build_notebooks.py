"""Execute every chapter notebook in order and save executed copies to executed/.

The notebooks in this folder are kept without outputs. This script runs them from a
clean scoreboard (chapters 04-10 add their scores to results/ in order, and the
capstone reads them), and writes copies with all outputs to executed/, which is what
the course website renders.

Usage (from this folder):
    python build_notebooks.py            # all chapters, about 25 minutes on a laptop
    python build_notebooks.py 07 08      # only the named chapters (they need earlier scores in results/)
"""

import sys
import time
from pathlib import Path

import nbformat
from nbclient import NotebookClient

HERE = Path(__file__).resolve().parent
OUT = HERE / "executed"


def main() -> None:
    wanted = set(sys.argv[1:])
    notebooks = sorted(p for p in HERE.glob("[0-9][0-9]_*.ipynb") if not wanted or p.name[:2] in wanted)
    if not wanted:
        for old in (HERE / "results").glob("*.csv"):
            old.unlink()                        # rebuild the scoreboard from scratch
    OUT.mkdir(exist_ok=True)
    for path in notebooks:
        start = time.time()
        nb = nbformat.read(path, as_version=4)
        NotebookClient(nb, timeout=3600, resources={"metadata": {"path": str(HERE)}}).execute()
        nbformat.write(nb, OUT / path.name)
        print(f"{path.name}: {time.time() - start:.0f}s")


if __name__ == "__main__":
    main()
