"""Shared helpers for the course notebooks.

Every notebook imports this module, so plotting style, data loading and
error metrics stay identical from chapter to chapter.
"""
import inspect
import warnings
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

DATA_DIR = Path(__file__).resolve().parent / "data"

PALETTE = ["#1f6feb", "#d1495b", "#2a9d8f", "#e9a03b", "#6c757d",
           "#8e44ad", "#8c564b", "#17becf"]

BEIJING_COLUMNS = {
    "PM_US Post": "pm25",
    "PM_Dongsi": "pm25_dongsi",
    "PM_Dongsihuan": "pm25_dongsihuan",
    "PM_Nongzhanguan": "pm25_nongzhanguan",
    "TEMP": "temp",
    "DEWP": "dew_point",
    "HUMI": "humidity",
    "PRES": "pressure",
    "cbwd": "wind_dir",
    "Iws": "cum_wind_speed",
    "precipitation": "precip",
    "Iprec": "cum_precip",
}


def set_style():
    """Apply the plotting defaults used throughout the course."""
    plt.rcParams.update({
        "figure.figsize": (12, 4),
        "figure.dpi": 100,
        "axes.grid": True,
        "grid.alpha": 0.3,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.prop_cycle": plt.cycler(color=PALETTE),
    })


def plot_acf_pacf(series, lags=20, title=""):
    """Sample ACF and PACF side by side, with ±1.96/√n white-noise bands (chapter 06)."""
    from statsmodels.tsa.stattools import acf, pacf

    series = pd.Series(series).dropna()
    fig, axes = plt.subplots(1, 2, figsize=(12, 3))
    band = 1.96 / np.sqrt(len(series))
    k = np.arange(1, lags + 1)
    for ax, name, values in [(axes[0], "ACF", acf(series, nlags=lags)[1:]),
                             (axes[1], "PACF", pacf(series, nlags=lags)[1:])]:
        ax.vlines(k, 0, values, lw=2)
        ax.axhline(0, color="k", lw=0.8)
        ax.axhspan(-band, band, color=PALETTE[0], alpha=0.12)
        ax.set(title=f"{title} {name}".strip(), xlabel="lag")
    fig.tight_layout()


def load_beijing(path=None):
    """Load the hourly Beijing air-quality data with a regular hourly index.

    This packages the cleaning steps worked through in chapter 01: build
    timestamps from the year/month/day/hour columns, rename the columns and
    enforce an hourly frequency. Missing readings are left as NaN.
    """
    path = Path(path) if path else DATA_DIR / "beijing_pm25.csv"
    raw = pd.read_csv(path)
    timestamps = pd.to_datetime(raw[["year", "month", "day", "hour"]])
    df = (
        raw.set_index(timestamps)
        .rename_axis("timestamp")
        .rename(columns=BEIJING_COLUMNS)[list(BEIJING_COLUMNS.values())]
    )
    # One hour (2015-11-07 13:00) records precipitation as 999990, a missing-data code.
    df.loc[df["precip"] >= 999990, ["precip", "cum_precip"]] = np.nan
    return df.asfreq("h")


# ---------------------------------------------------------------------------
# The course's standard forecasting task (defined in chapter 04)
# ---------------------------------------------------------------------------

#: Last day of the development period. Everything after it is the locked test year.
DEV_END = "2014-12-31"
#: Forecast horizon in days.
HORIZON = 7
#: One forecast origin per day, so every target date falls inside 2014.
BACKTEST_ORIGINS = pd.date_range("2013-12-31", "2014-12-24", freq="D")
#: The locked test year's origins, used once, in the capstone (chapter 11).
TEST_ORIGINS = pd.date_range("2014-12-31", "2015-12-24", freq="D")


def load_daily_pm25(min_hours=18):
    """Daily mean PM2.5 with two columns.

    ``pm25``: gap-free daily means, for models to learn from; days with fewer
    than ``min_hours`` hourly readings are interpolated.
    ``actual``: the same values, but NaN on those thin days, so they are
    never used to score a forecast.
    """
    pm = load_beijing()["pm25"].interpolate(method="time", limit=3, limit_area="inside")
    daily = pm.resample("D").agg(["mean", "count"])
    actual = daily["mean"].where(daily["count"] >= min_hours)
    return pd.DataFrame({"pm25": actual.interpolate(limit_direction="both"), "actual": actual})


def load_daily_weather():
    """Daily weather summaries for Beijing, on the same days as ``load_daily_pm25``.

    Columns: daily means of dew point, humidity, pressure and temperature;
    total precipitation; share of hours with north-westerly (``nw_share``) or
    calm/variable (``calm_share``) wind; mean cumulated wind speed (``wind``);
    evening (18:00–23:00) north-westerly share and humidity; and day-on-day
    changes in pressure and humidity. The few missing days are interpolated.
    """
    hourly = load_beijing()
    evening = hourly.between_time("18:00", "23:00")
    daily = pd.DataFrame({
        "dew_point": hourly["dew_point"].resample("D").mean(),
        "humidity": hourly["humidity"].resample("D").mean(),
        "pressure": hourly["pressure"].resample("D").mean(),
        "temp": hourly["temp"].resample("D").mean(),
        "precip": hourly["precip"].resample("D").sum(min_count=1),
        "nw_share": (hourly["wind_dir"] == "NW").resample("D").mean(),
        "calm_share": (hourly["wind_dir"] == "cv").resample("D").mean(),
        "wind": hourly["cum_wind_speed"].resample("D").mean(),
        "nw_evening": (evening["wind_dir"] == "NW").resample("D").mean(),
        "humidity_evening": evening["humidity"].resample("D").mean(),
    })
    daily["pressure_change"] = daily["pressure"].diff()
    daily["humidity_change"] = daily["humidity"].diff()
    return daily.interpolate(limit_direction="both")


#: Lunar New Year's Day (Spring Festival) for the years in the data (chapter 08).
SPRING_FESTIVAL = pd.to_datetime(["2010-02-14", "2011-02-03", "2012-01-23",
                                  "2013-02-10", "2014-01-31", "2015-02-19"])

#: Weather features observed by the end of each day (chapter 07, approach C).
KNOWN_TODAY_WEATHER = ["nw_share", "calm_share", "humidity", "wind",
                       "nw_evening", "humidity_evening", "pressure_change", "humidity_change"]


def ml_features(y, weather, horizon):
    """Features for forecasting ``horizon`` days ahead, one row per forecast origin (chapter 09).

    Every column is known by the end of the origin day: trailing lags and
    rolling statistics of log PM2.5, that day's weather, and calendar facts
    about the *target* date (which are known in advance).
    """
    log_y = np.log(y)
    X = pd.DataFrame(index=y.index)
    for k in [0, 1, 2, 3, 6, 13, 27]:
        X[f"lag_{k}"] = log_y.shift(k)
    for window in [3, 7, 30]:
        X[f"mean_{window}"] = log_y.rolling(window).mean()
    X["std_7"] = log_y.rolling(7).std()
    X["change_1"] = log_y.diff()
    for column in KNOWN_TODAY_WEATHER:
        X[column] = weather[column]

    target_date = X.index + pd.Timedelta(days=horizon)
    doy = target_date.dayofyear.to_numpy()
    for k in (1, 2):
        X[f"sin_{k}"] = np.sin(2 * np.pi * k * doy / 365.25)
        X[f"cos_{k}"] = np.cos(2 * np.pi * k * doy / 365.25)
    X["target_dow"] = target_date.dayofweek
    X["target_is_festival"] = target_date.isin(SPRING_FESTIVAL).astype(int)
    X["target_is_festival_eve"] = (target_date + pd.Timedelta(days=1)).isin(SPRING_FESTIVAL).astype(int)
    return X


def backtest(y, forecaster, origins, horizon, actuals=None):
    """Rolling-origin evaluation.

    For each origin, ``forecaster(history, horizon)`` sees only ``y`` up to and
    including the origin and returns ``horizon`` forecasts. Forecasts are
    paired with ``actuals`` (default ``y``); targets past the end of the data
    are dropped. Returns one row per (origin, step ahead).
    """
    actuals = y if actuals is None else actuals
    rows = []
    for origin in origins:
        pos = y.index.get_loc(origin)
        history = y.iloc[: pos + 1]
        forecast = np.asarray(forecaster(history, horizon), dtype=float)
        dates = y.index[pos + 1 : pos + 1 + horizon]
        rows.append(pd.DataFrame({
            "origin": origin,
            "h": np.arange(1, len(dates) + 1),
            "date": dates,
            "forecast": forecast[: len(dates)],
            "actual": actuals.reindex(dates).to_numpy(),
        }))
    return pd.concat(rows, ignore_index=True)


def evaluate(bt):
    """MAE, RMSE, bias and count per step ahead, skipping rows with no actual."""
    bt = bt.dropna(subset=["actual"])
    err = bt["forecast"] - bt["actual"]
    grouped = err.groupby(bt["h"])
    return pd.DataFrame({
        "MAE": grouped.apply(lambda e: e.abs().mean()),
        "RMSE": grouped.apply(lambda e: np.sqrt((e**2).mean())),
        "bias": grouped.mean(),
        "n": grouped.size(),
    })


def naive_forecast(history, horizon):
    """Every future value equals the last observed value."""
    return np.full(horizon, history.iloc[-1])


def climatology_forecast(history, horizon, window=15, stat="median"):
    """Typical value for each target's time of year.

    Uses every past value within ``window`` days of the target's day of the
    year (wrapping around New Year), summarised by ``stat``.
    """
    targets = pd.date_range(history.index[-1] + pd.Timedelta(days=1), periods=horizon, freq="D")
    doy = history.index.dayofyear.to_numpy()
    values = history.to_numpy()
    summarise = np.median if stat == "median" else np.mean
    out = []
    for target_doy in targets.dayofyear:
        dist = np.abs(doy - target_doy)
        dist = np.minimum(dist, 365 - dist)
        out.append(summarise(values[dist <= window]))
    return np.array(out)


def log_climatology_profile(history, window=31):
    """Smooth day-of-year profile of log PM2.5, learned from ``history`` only.

    Takes the median log value for each day of the year, then smooths the
    366 medians with a centred moving average of ``window`` days that wraps
    around New Year. Returns a Series indexed by day of year (1–366).
    """
    log_h = np.log(history)
    medians = (log_h.groupby(log_h.index.dayofyear).median()
               .reindex(range(1, 367)).interpolate(limit_direction="both").to_numpy())
    half = window // 2
    padded = np.r_[medians[-half:], medians, medians[:half]]
    smooth = np.convolve(padded, np.ones(window) / window, mode="valid")
    return pd.Series(smooth, index=pd.RangeIndex(1, 367, name="dayofyear"))


RESULTS_PATH = Path(__file__).resolve().parent / "results" / "daily_pm25_backtest_2014.csv"
#: Scores that rely on information unavailable at forecast time (e.g. perfect
#: weather forecasts). Kept apart so they never enter the main leaderboard.
ORACLE_RESULTS_PATH = RESULTS_PATH.with_name("oracle_scores_2014.csv")


def save_scores(model, scores, path=RESULTS_PATH):
    """Store a model's per-horizon scores (output of ``evaluate``) on the leaderboard.

    Saving again under the same model name replaces its previous entry.
    """
    path.parent.mkdir(exist_ok=True)
    new = scores.reset_index().assign(model=model)
    if path.exists():
        old = pd.read_csv(path)
        new = pd.concat([old[old["model"] != model], new], ignore_index=True)
    new.to_csv(path, index=False)


def load_scores(path=RESULTS_PATH):
    """All saved scores, one row per (model, step ahead)."""
    return pd.read_csv(path)


def _test_pvalue(test, y, **kwargs):
    """Call a statsmodels test and return its p-value on old and new versions.

    statsmodels 0.15 added ``result_object=True`` (returning an object with
    ``.pvalue``) and plans to make it the default; older versions return a
    tuple with the p-value in position 1.
    """
    if "result_object" in inspect.signature(test).parameters:
        return test(y, result_object=True, **kwargs).pvalue
    return test(y, **kwargs)[1]


def adf_pvalue(y, regression="c"):
    """p-value of the Augmented Dickey-Fuller test (null: unit root)."""
    from statsmodels.tsa.stattools import adfuller

    return _test_pvalue(adfuller, y, regression=regression, autolag="AIC")


def kpss_pvalue(y, regression="c"):
    """p-value of the KPSS test (null: stationary), clipped to [0.01, 0.10]."""
    from statsmodels.tools.sm_exceptions import InterpolationWarning
    from statsmodels.tsa.stattools import kpss

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", InterpolationWarning)
        return _test_pvalue(kpss, y, regression=regression, nlags="auto")


def stationarity_tests(y, regression="c", alpha=0.05):
    """Run the ADF and KPSS tests and combine them into one verdict.

    ADF's null hypothesis is a unit root; KPSS's is stationarity, so the two
    are complementary. ``regression="c"`` tests stationarity around a constant
    mean, ``"ct"`` around a linear trend. KPSS p-values come from a lookup
    table and are clipped to [0.01, 0.10].
    """
    y = pd.Series(y).dropna()
    adf_p = adf_pvalue(y, regression)
    kpss_p = kpss_pvalue(y, regression)

    adf_says_stationary = adf_p < alpha
    kpss_says_stationary = kpss_p >= alpha
    kind = "trend-stationary" if regression == "ct" else "stationary"
    verdict = {
        (True, True): kind,
        (False, False): "unit root",
        (True, False): "conflict: fast mean reversion, but level drifts",
        (False, True): "inconclusive: neither test rejects",
    }[(adf_says_stationary, kpss_says_stationary)]
    return pd.Series({"ADF p": round(adf_p, 3), "KPSS p": round(kpss_p, 3), "verdict": verdict})


def mae(y_true, y_pred):
    """Mean absolute error."""
    y_true, y_pred = np.asarray(y_true, float), np.asarray(y_pred, float)
    return np.mean(np.abs(y_true - y_pred))


def rmse(y_true, y_pred):
    """Root mean squared error."""
    y_true, y_pred = np.asarray(y_true, float), np.asarray(y_pred, float)
    return np.sqrt(np.mean((y_true - y_pred) ** 2))


def mase(y_true, y_pred, y_train, season=1):
    """Mean absolute scaled error.

    The forecast's MAE divided by the in-sample MAE of a seasonal-naive
    forecast on the training data. Values below 1 beat that baseline.
    """
    y_train = np.asarray(y_train, float)
    scale = np.mean(np.abs(y_train[season:] - y_train[:-season]))
    return mae(y_true, y_pred) / scale
