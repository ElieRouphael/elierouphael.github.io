# Notice

This repository is an independent educational implementation. Its text and code are original.

The choice of topics and several examples were informed by the material of a 2025–2026 advanced-control course on Learning MPC (Università di Napoli Federico II, Université Franco-Italienne and Grenoble INP / ENSE3). That material is not included in this repository; its authors and contributors retain all rights to it. See `docs/references.md` for the full acknowledgement.
