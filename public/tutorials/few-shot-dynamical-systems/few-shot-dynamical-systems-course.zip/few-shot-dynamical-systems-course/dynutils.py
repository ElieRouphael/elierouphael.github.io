"""Shared simulator, learner and pretraining code for the few-shot dynamical-systems course.

This course is one sequential narrative (unlike the standalone-chapter "A Tour of Machine
Learning" course): chapters 03-08 all need the pretrained `Family` built in chapter 03. Rather
than saving it to disk, every chapter that needs it calls `build_family` with a freshly-seeded
`np.random.default_rng(SEED)`, which regenerates it deterministically from scratch in well under
a second. That keeps every chapter independently runnable while staying numerically identical
wherever the family is rebuilt.

The physics, the estimators and the plotting are unchanged from the original tutorial notebook
(`few_shot_system_identification_tutorial.ipynb`) and its generator script
(`tools/build_tutorial_notebook.py`); this module only collects the pieces shared across chapters.
"""
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Ellipse
from scipy.optimize import least_squares

SEED = 2026

DT = 0.1                                  # sampling time [s]
X0 = np.array([0.2, 0.0])                 # every experiment starts at rest, deflected by 0.2
NAMES = ["k", "d", "b", "α"]

# Hidden family structure: known to the simulator only, never to the learner.
_ETA0 = np.array([1.20, 0.32, 0.90, 1.00])
_M = np.array([[0.55, 0.12], [0.07, 0.11], [0.16, -0.09], [0.30, 0.45]])
_SIGMA_Y, _SIGMA_W, _RHO = 0.01, 0.01, 0.8     # sensor noise, disturbance strength, disturbance colour

LOW = np.array([0.05, 0.01, 0.05, 0.0])
HIGH = np.array([5.0, 2.0, 3.0, 5.0])
GENERIC_GUESS = np.array([1.0, 0.5, 1.0, 0.5])

# One colour per method, used in every figure.
COLOR = dict(
    truth="#0b0b0b", measured="#9a9893", none="#9a9893", scratch="#eb6834",
    context="#2a78d6", designed="#1baf7a", worst="#e87ba4", reference="#52514e",
)


def set_style() -> None:
    plt.rcParams.update({
        "figure.figsize": (10, 3.6), "figure.dpi": 110, "axes.grid": True, "grid.alpha": 0.25,
        "axes.spines.top": False, "axes.spines.right": False, "lines.linewidth": 2,
        "legend.frameon": False, "font.size": 10,
    })


# ---------------------------------------------------------------- the plant

def actuator(u):
    return 0.3 * np.tanh(np.asarray(u) / 0.6)


def sample_system(rng, context=None):
    """Draw a new member of the family (the 'secret' ground truth)."""
    c = rng.uniform(-1, 1, 2) if context is None else np.asarray(context, float)
    eta = _ETA0 + _M @ c + rng.normal(scale=[0.015, 0.004, 0.008, 0.04])
    return dict(eta=eta, context=c,
                gamma=0.035 + 0.012 * rng.uniform(),        # unmodelled quintic spring
                bias=0.006 * c[0] + 0.002 * rng.normal())   # unmodelled force bias


def simulate(system, u, rng, noise=True):
    """True plant. Returns (true positions, noisy position measurements), length len(u)+1."""
    k, d, b, a = system["eta"]
    u_delayed = np.r_[0.0, np.asarray(u, float)[:-1]]
    (q, v), w = X0, 0.0
    qs = [q]
    for ut in u_delayed:
        if noise:
            w = _RHO * w + _SIGMA_W * rng.normal()
        acc = (-k * q - d * v + b * actuator(ut) - a * q**3
               - system["gamma"] * q**5 + system["bias"] + w)
        v = v + DT * acc                  # semi-implicit Euler
        q = q + DT * v
        qs.append(q)
    qs = np.array(qs)
    y = qs + (_SIGMA_Y * rng.normal(size=qs.size) if noise else 0.0)
    return qs, y


def multisine(T, rng, n=3, fmin=0.02, fmax=0.8):
    """Random admissible input: a sum of n sines with random frequencies [Hz] and phases, peak 1."""
    t = DT * np.arange(T)
    f = np.exp(rng.uniform(np.log(fmin), np.log(fmax), n))
    s = sum(np.sin(2 * np.pi * fi * t + rng.uniform(0, 2 * np.pi)) for fi in f)
    return s / np.abs(s).max()


# ---------------------------------------------------------------- the learner's model

def predict(eta, u):
    """Learner's model: simulate positions. Vectorised: eta (..., 4) and u (..., T) broadcast."""
    eta, u = np.asarray(eta, float), np.asarray(u, float)
    shape = np.broadcast_shapes(eta.shape[:-1], u.shape[:-1])
    k, d, b, a = (np.broadcast_to(eta[..., i], shape) for i in range(4))
    force = actuator(np.concatenate([np.zeros(u.shape[:-1] + (1,)), u[..., :-1]], axis=-1))
    q, v = np.full(shape, X0[0]), np.full(shape, X0[1])
    out = np.empty(shape + (u.shape[-1] + 1,)); out[..., 0] = q
    for t in range(u.shape[-1]):
        v = v + DT * (-k * q - d * v + b * force[..., t] - a * q**3)
        q = q + DT * v
        out[..., t + 1] = q
    return out


def fit_from_scratch(y, u, return_cov=False):
    residual = lambda eta: predict(eta, u) - y
    sol = least_squares(residual, GENERIC_GUESS, bounds=(LOW, HIGH), x_scale="jac")
    if not return_cov:
        return sol.x
    # Gauss-Newton covariance of the estimate: sigma^2 (J^T J)^-1
    return sol.x, np.mean(sol.fun**2) * np.linalg.pinv(sol.jac.T @ sol.jac)


def rmse(a, b):
    return float(np.sqrt(np.mean((np.asarray(a) - np.asarray(b)) ** 2)))


# ---------------------------------------------------------------- pretraining: the Family

class Family:
    """Pretrained low-dimensional model of a family of systems."""

    def fit(self, fits, data, rank=2, whiten=True):
        # fits: list of (eta_hat, covariance) from fit_from_scratch(..., return_cov=True)
        self.eta_hat = np.array([eta for eta, _ in fits])
        self.sigma = np.sqrt(np.mean([np.mean((predict(e, u) - y) ** 2)
                                      for e, (y, u) in zip(self.eta_hat, data)]))
        self.mean = self.eta_hat.mean(axis=0)
        self.scale = (np.sqrt(np.mean([np.diag(cov) for _, cov in fits], axis=0))
                      if whiten else np.ones(4))
        centred = (self.eta_hat - self.mean) / self.scale
        _, sv, vt = np.linalg.svd(centred, full_matrices=False)
        var = sv**2 / (len(centred) - 1)
        self.explained = var / var.sum()
        self.U = self.scale[:, None] * vt[:rank].T * np.sqrt(var[:rank])
        self.z_train = centred @ vt[:rank].T / np.sqrt(var[:rank])
        return self

    def decode(self, z):
        return np.clip(self.mean + np.asarray(z) @ self.U.T, LOW, HIGH)

    def project(self, eta):
        # Best context for known coefficients, in the whitened metric (used only for evaluation).
        return np.linalg.lstsq(self.U / self.scale[:, None], (eta - self.mean) / self.scale, rcond=None)[0]


def r_squared(Z, C):
    """Share of the variance of the hidden variables C explained by an affine function of Z."""
    A = np.c_[Z, np.ones(len(Z))]
    residual = C - A @ np.linalg.lstsq(A, C, rcond=None)[0]
    return 1 - (residual**2).sum(axis=0) / ((C - C.mean(axis=0)) ** 2).sum(axis=0)


def build_family(rng, n_systems=20, T=800, n=6, rank=2, whiten=True):
    """Rebuild the pretrained Family exactly as chapter 03 does.

    Call with a freshly-seeded ``rng = np.random.default_rng(dynutils.SEED)`` to get the
    same family every time, in every chapter: 20 training systems, each identified from an
    80-second recording. Returns ``(family, train_systems, train_data, train_fits)``.
    """
    train_systems = [sample_system(rng) for _ in range(n_systems)]
    train_data = []
    for s in train_systems:
        u = multisine(T, rng, n=n)
        train_data.append((simulate(s, u, rng)[1], u))
    train_fits = [fit_from_scratch(y, u, return_cov=True) for y, u in train_data]
    family = Family().fit(train_fits, train_data, rank=rank, whiten=whiten)
    return family, train_systems, train_data, train_fits


# ---------------------------------------------------------------- few-shot adaptation

def adapt(family, y, u):
    """MAP estimate of the context, its Laplace covariance, and the RMS output misfit."""
    residual = lambda z: np.r_[(predict(family.decode(z), u) - y) / family.sigma, z]
    sol = least_squares(residual, np.zeros(family.U.shape[1]))
    S = sol.jac[:-len(sol.x)] * family.sigma
    cov = np.linalg.inv(S.T @ S / family.sigma**2 + np.eye(len(sol.x)))
    misfit = rmse(predict(family.decode(sol.x), u), y)
    return sol.x, cov, misfit


def ellipse(ax, mean, cov, color, label=None, n_std=2.0):
    vals, vecs = np.linalg.eigh(cov)
    angle = np.degrees(np.arctan2(vecs[1, -1], vecs[0, -1]))
    ax.add_patch(Ellipse(mean, *(2 * n_std * np.sqrt(vals[::-1])), angle=angle,
                         fill=False, color=color, lw=2, label=label))


# ---------------------------------------------------------------- experiment design

def fisher(family, U_in, Z, eps=1e-4):
    """Fisher information for inputs U_in (N, T) at contexts Z (M, 2) -> array (N, M, 2, 2)."""
    U_in = np.asarray(U_in)[:, None, :]
    S = np.stack([(predict(family.decode(Z + eps * e)[None], U_in)
                   - predict(family.decode(Z - eps * e)[None], U_in)) / (2 * eps)
                  for e in np.eye(2)], axis=-1)
    return np.einsum("nmti,nmtj->nmij", S, S) / family.sigma**2 + np.eye(2)


def design_score(family, U_in):
    return np.linalg.slogdet(fisher(family, U_in, family.z_train))[1].mean(axis=1)


# ---------------------------------------------------------------- model-based control

def feedforward(eta, ref, lam=0.05, eps=1e-5):
    T_ctrl = len(ref) - 1

    def residual(u):
        return np.r_[predict(eta, u) - ref, np.sqrt(lam) * np.diff(u)]

    def jacobian(u):                                       # vectorised finite differences
        batch = u + eps * np.vstack([np.zeros(T_ctrl), np.eye(T_ctrl)])
        r = np.c_[predict(eta, batch) - ref, np.sqrt(lam) * np.diff(batch, axis=1)]
        return ((r[1:] - r[0]) / eps).T

    return least_squares(residual, np.zeros(T_ctrl), jac=jacobian, bounds=(-2, 2)).x
